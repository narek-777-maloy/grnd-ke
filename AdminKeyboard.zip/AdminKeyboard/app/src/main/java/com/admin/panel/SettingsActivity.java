package com.admin.panel;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Экран настроек: включить клавиатуру и поправить команды сервера. */
public class SettingsActivity extends Activity {
    private static final String[][] FIELDS = {
        {"ans", "Команда ответа на репорт"},
        {"re", "Команда слежки"},
        {"go", "ТП к игроку"},
        {"gh", "ТП игрока к себе"},
        {"prefix", "Приставка к быстрым ответам"},
        {"delay", "Пауза между двумя командами (мс)"}
    };
    private final EditText[] edits = new EditText[FIELDS.length];

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(p, p, p, p);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);

        TextView title = new TextView(this);
        title.setText("Админ-клавиатура");
        title.setTextSize(22);
        l.addView(title);

        TextView info = new TextView(this);
        info.setText("1) Нажми «Включить» и включи «Админ-клава».\n"
            + "2) Открой чат игры, нажми «Выбрать» и выбери «Админ-клава».\n"
            + "3) Вводи ID цифрами. После 2 цифр появятся кнопки. Нажал кнопку: команда подставилась в чат "
            + "(и отправилась, если включено ⏎). Наказания: второе нажатие подтверждает.\n");
        l.addView(info);

        l.addView(button("1. Включить клавиатуру",
            v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))));
        l.addView(button("2. Выбрать клавиатуру",
            v -> ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showInputMethodPicker()));

        for (int i = 0; i < FIELDS.length; i++) {
            TextView lb = new TextView(this);
            lb.setText(FIELDS[i][1]);
            lb.setPadding(0, p / 2, 0, 0);
            l.addView(lb);
            edits[i] = new EditText(this);
            edits[i].setSingleLine(true);
            edits[i].setText(Cfg.s(this, FIELDS[i][0]));
            l.addView(edits[i]);
        }

        final CheckBox auto = new CheckBox(this);
        auto.setText("Сразу отправлять (Enter) после подстановки");
        auto.setChecked(Cfg.auto(this));
        l.addView(auto);

        l.addView(button("Сохранить", v -> {
            SharedPreferences.Editor ed = Cfg.p(this).edit();
            for (int i = 0; i < FIELDS.length; i++) ed.putString(FIELDS[i][0], edits[i].getText().toString());
            ed.putBoolean("auto", auto.isChecked()).apply();
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
        }));
    }

    private Button button(String text, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setOnClickListener(l);
        return bt;
    }
}
