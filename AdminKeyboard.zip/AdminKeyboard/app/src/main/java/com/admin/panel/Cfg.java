package com.admin.panel;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки (хранятся на телефоне, меняются в приложении «Админ-клава»). */
final class Cfg {
    static SharedPreferences p(Context c) { return c.getSharedPreferences("ap", Context.MODE_PRIVATE); }

    static String def(String k) {
        switch (k) {
            case "ans": return "/ans";            // ответ на репорт: /ans <id> <текст>
            case "re": return "/re";              // слежка
            case "go": return "/goto";            // ТП к игроку
            case "gh": return "/gethere";         // ТП игрока к себе
            case "prefix": return "Приветствую, "; // приставка к быстрым ответам
            case "delay": return "900";           // пауза между двумя командами, мс
            default: return "";
        }
    }

    static String s(Context c, String k) { return p(c).getString(k, def(k)); }
    static boolean auto(Context c) { return p(c).getBoolean("auto", true); }

    static long delay(Context c) {
        try { return Long.parseLong(s(c, "delay").trim()); } catch (Exception e) { return 900; }
    }
}
