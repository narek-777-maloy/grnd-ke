package com.admin.panel;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** Клавиатура: вводишь ID цифрами, после 2 цифр появляются кнопки, нажатие подставляет команду в чат. */
public class AdminKeyboardService extends InputMethodService {
    private static final int BG = 0xFF15181D, KEY = 0xFF2B303A, DANGER = 0xFF5A2E22, ARMED = 0xFFB3261E, ACCENT = 0xFF2F6FED;

    private final StringBuilder id = new StringBuilder();
    private final Handler h = new Handler(Looper.getMainLooper());
    private int tab = 0;
    private String armedKey = null;
    private long armedAt = 0;

    private TextView idView, autoView, hint;
    private final TextView[] tabViews = new TextView[4];
    private LinearLayout menu;
    private GridLayout grid;

    @Override public boolean onEvaluateFullscreenMode() { return false; } // без «полноэкранного» режима в ландшафте

    @Override public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(4), dp(2), dp(4), dp(4));

        // верхняя строка: ID + цифры + стереть + смена клавиатуры
        LinearLayout top = new LinearLayout(this);
        idView = new TextView(this);
        idView.setTextColor(Color.WHITE);
        idView.setTextSize(17);
        idView.setTypeface(null, Typeface.BOLD);
        idView.setGravity(Gravity.CENTER_VERTICAL);
        idView.setPadding(dp(8), 0, 0, 0);
        top.addView(idView, new LinearLayout.LayoutParams(0, dp(44), 2.4f));
        for (int i = 1; i <= 10; i++) {
            final String d = String.valueOf(i % 10);
            top.addView(key(d, KEY, 19, v -> addDigit(d)), cell(1f));
        }
        TextView bs = key("⌫", DANGER, 19, v -> back());
        bs.setOnLongClickListener(v -> { id.setLength(0); refresh(); return true; });
        top.addView(bs, cell(1.3f));
        top.addView(key("🌐", KEY, 17, v ->
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showInputMethodPicker()), cell(1f));
        root.addView(top);

        hint = new TextView(this);
        hint.setText("Введи ID игрока (от 2 цифр), появятся кнопки");
        hint.setTextColor(0xFF8A93A0);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint, new LinearLayout.LayoutParams(-1, dp(40)));

        // меню: вкладки + сетка кнопок
        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        LinearLayout tabs = new LinearLayout(this);
        String[] names = {"Ответы", "Работы", "Наказания", "Действия"};
        for (int i = 0; i < 4; i++) {
            final int n = i;
            tabViews[i] = key(names[i], KEY, 13, v -> { tab = n; armedKey = null; buildGrid(); });
            tabs.addView(tabViews[i], cell(1f, 34));
        }
        autoView = key("", KEY, 13, v -> {
            Cfg.p(this).edit().putBoolean("auto", !Cfg.auto(this)).apply();
            buildGrid();
        });
        tabs.addView(autoView, cell(1f, 34));
        menu.addView(tabs);

        grid = new GridLayout(this);
        float wdp = getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density;
        grid.setColumnCount(Math.max(3, (int) (wdp / 135)));
        ScrollView sv = new ScrollView(this);
        sv.addView(grid);
        menu.addView(sv, new LinearLayout.LayoutParams(-1, dp(112)));
        root.addView(menu);

        buildGrid();
        refresh();
        return root;
    }

    @Override public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        id.setLength(0);
        refresh();
        buildGrid();
    }

    // ---------- ввод ID ----------
    private void addDigit(String d) { if (id.length() < 4) id.append(d); refresh(); }
    private void back() { if (id.length() > 0) id.setLength(id.length() - 1); refresh(); }

    private void refresh() {
        if (idView == null) return;
        idView.setText(id.length() == 0 ? "ID: —" : "ID: " + id);
        boolean on = id.length() >= 2;
        menu.setVisibility(on ? View.VISIBLE : View.GONE);
        hint.setVisibility(on ? View.GONE : View.VISIBLE);
    }

    // ---------- кнопки ----------
    private void buildGrid() {
        if (grid == null) return;
        for (int i = 0; i < 4; i++) bg(tabViews[i], i == tab ? ACCENT : KEY);
        autoView.setText(Cfg.auto(this) ? "⏎ вкл" : "⏎ выкл");
        grid.removeAllViews();

        if (tab == 0) {
            for (String[] a : Data.ANSWERS) {
                final String m = a[1];
                add(a[0], KEY, () -> send(Cfg.s(this, "prefix") + m, null, ""));
            }
        } else if (tab == 1) {
            for (String[] a : Data.JOBS) {
                final String m = a[1];
                add(a[0], KEY, () -> send(m, null, ""));
            }
        } else if (tab == 2) {
            for (int i = 0; i < Data.PUNS.length; i++) {
                final String[] p = Data.PUNS[i];
                final String k = "p" + i;
                final boolean hasCmd = !p[1].isEmpty();
                final boolean armed = hasCmd && k.equals(armedKey) && System.currentTimeMillis() - armedAt < 3000;
                add(armed ? "ТОЧНО? " + p[0] : p[0], armed ? ARMED : (hasCmd ? DANGER : KEY), () -> {
                    if (hasCmd && !armed) {              // наказание: второе нажатие подтверждает
                        armedKey = k;
                        armedAt = System.currentTimeMillis();
                        buildGrid();
                        h.postDelayed(this::buildGrid, 3100);
                    } else {
                        armedKey = null;
                        send(p[3], p[1], p[2]);
                    }
                });
            }
        } else {
            add("Слежка " + Cfg.s(this, "re"), KEY, () -> send(null, Cfg.s(this, "re"), ""));
            add("ТП к игроку " + Cfg.s(this, "go"), KEY, () -> send(null, Cfg.s(this, "go"), ""));
            add("ТП ко мне " + Cfg.s(this, "gh"), KEY, () -> send(null, Cfg.s(this, "gh"), ""));
        }
    }

    private void add(String label, int color, Runnable r) {
        TextView v = key(label, color, 12, x -> r.run());
        v.setMaxLines(2);
        v.setPadding(dp(4), 0, dp(4), 0);
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
            GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        lp.height = dp(38);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        grid.addView(v, lp);
    }

    // ---------- отправка в чат ----------
    /** msg: ответ игроку (/ans ID msg), cmd+args: вторая команда (наказание/слежка и т.п.). */
    private void send(String msg, String cmd, String args) {
        final String pid = id.toString();
        if (pid.isEmpty()) return;
        List<String> list = new ArrayList<>();
        if (msg != null) list.add(Cfg.s(this, "ans") + " " + pid + " " + msg);
        if (cmd != null && !cmd.isEmpty()) list.add(cmd + " " + pid + (args == null || args.isEmpty() ? "" : " " + args));
        final boolean enter = list.size() > 1 || Cfg.auto(this);
        long delay = 0;
        for (int i = 0; i < list.size(); i++) {
            final String text = list.get(i);
            final boolean send = i < list.size() - 1 || enter;
            h.postDelayed(() -> put(text, send), delay);
            delay += Cfg.delay(this);
        }
        id.setLength(0);
        refresh();
    }

    /** Заменяет содержимое поля чата текстом и (по желанию) жмёт Enter. */
    private void put(String text, boolean enter) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.beginBatchEdit();
        ic.deleteSurroundingText(10000, 10000);
        ic.commitText(text, 1);
        ic.endBatchEdit();
        if (enter && !sendDefaultEditorAction(true)) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }

    // ---------- мелочи ----------
    private TextView key(String t, int color, float sp, View.OnClickListener l) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Color.WHITE);
        v.setTextSize(sp);
        v.setGravity(Gravity.CENTER);
        bg(v, color);
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.setAlpha(0.6f);
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) x.setAlpha(1f);
            return false;
        });
        v.setOnClickListener(x -> {
            x.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            l.onClick(x);
        });
        return v;
    }

    private void bg(View v, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(8));
        v.setBackground(g);
    }

    private LinearLayout.LayoutParams cell(float w) { return cell(w, 44); }

    private LinearLayout.LayoutParams cell(float w, int hDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(hDp), w);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        return lp;
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
}
